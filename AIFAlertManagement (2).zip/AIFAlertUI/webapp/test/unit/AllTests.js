sap.ui.define([
	"com/sap/aif/AIFAlertUI/test/unit/controller/Root.controller"
], function () {
	"use strict";
});